﻿--
-- Скрипт сгенерирован Devart dbForge Studio 2020 for MySQL, Версия 9.0.391.0
-- Домашняя страница продукта: http://www.devart.com/ru/dbforge/mysql/studio
-- Дата скрипта: 03.09.2020 17:36:44
-- Версия сервера: 8.0.21
-- Версия клиента: 4.1
--

-- 
-- Отключение внешних ключей
-- 
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;

-- 
-- Установить режим SQL (SQL mode)
-- 
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- 
-- Установка кодировки, с использованием которой клиент будет посылать запросы на сервер
--
SET NAMES 'utf8';

--
-- Установка базы данных по умолчанию
--
USE kinopoisk;

--
-- Удалить таблицу `FavoriteFilms`
--
DROP TABLE IF EXISTS FavoriteFilms;

--
-- Удалить таблицу `MovieCountry`
--
DROP TABLE IF EXISTS MovieCountry;

--
-- Удалить таблицу `MovieGenre`
--
DROP TABLE IF EXISTS MovieGenre;

--
-- Удалить таблицу `MovieRating`
--
DROP TABLE IF EXISTS MovieRating;

--
-- Удалить таблицу `WillWatch`
--
DROP TABLE IF EXISTS WillWatch;

--
-- Удалить таблицу `Movie`
--
DROP TABLE IF EXISTS Movie;

--
-- Удалить таблицу `Profile`
--
DROP TABLE IF EXISTS Profile;

--
-- Удалить таблицу `User`
--
DROP TABLE IF EXISTS User;

--
-- Удалить таблицу `Country`
--
DROP TABLE IF EXISTS Country;

--
-- Удалить таблицу `Genre`
--
DROP TABLE IF EXISTS Genre;

--
-- Удалить таблицу `Gender`
--
DROP TABLE IF EXISTS Gender;

--
-- Установка базы данных по умолчанию
--
USE kinopoisk;

--
-- Создать таблицу `Gender`
--
CREATE TABLE Gender (
  Id int UNSIGNED NOT NULL AUTO_INCREMENT,
  Name varchar(50) DEFAULT NULL,
  PRIMARY KEY (Id)
)
ENGINE = INNODB,
CHARACTER SET utf8mb4,
COLLATE utf8mb4_0900_ai_ci;

--
-- Создать таблицу `Genre`
--
CREATE TABLE Genre (
  Id int UNSIGNED NOT NULL AUTO_INCREMENT,
  Name varchar(50) DEFAULT NULL,
  Created datetime DEFAULT (NOW()),
  Updated datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (Id)
)
ENGINE = INNODB,
CHARACTER SET utf8mb4,
COLLATE utf8mb4_0900_ai_ci;

--
-- Создать таблицу `Country`
--
CREATE TABLE Country (
  Id int UNSIGNED NOT NULL AUTO_INCREMENT,
  Name varchar(50) DEFAULT NULL,
  Created datetime DEFAULT (NOW()),
  Updated datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (Id)
)
ENGINE = INNODB,
CHARACTER SET utf8mb4,
COLLATE utf8mb4_0900_ai_ci;

--
-- Создать таблицу `User`
--
CREATE TABLE User (
  Id int UNSIGNED NOT NULL AUTO_INCREMENT,
  UserName varchar(255) NOT NULL DEFAULT '',
  Email varchar(255) NOT NULL DEFAULT '',
  Created datetime DEFAULT (NOW()),
  Updated datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (Id)
)
ENGINE = INNODB,
CHARACTER SET utf8mb4,
COLLATE utf8mb4_0900_ai_ci,
COMMENT = 'Пользователь';

--
-- Создать таблицу `Profile`
--
CREATE TABLE Profile (
  UserId int UNSIGNED NOT NULL,
  FirstName varchar(255) NOT NULL DEFAULT '',
  LastName varchar(255) NOT NULL DEFAULT '',
  GenderId int UNSIGNED NOT NULL,
  Birthday date DEFAULT NULL,
  СountryId int UNSIGNED NOT NULL,
  City varchar(130) NOT NULL DEFAULT '',
  Created datetime DEFAULT (NOW()),
  Updated datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
)
ENGINE = INNODB,
CHARACTER SET utf8mb4,
COLLATE utf8mb4_0900_ai_ci,
COMMENT = 'Профиль';

--
-- Создать внешний ключ
--
ALTER TABLE Profile
ADD CONSTRAINT FK_Profile_Country_Id FOREIGN KEY (СountryId)
REFERENCES Country (Id);

--
-- Создать внешний ключ
--
ALTER TABLE Profile
ADD CONSTRAINT FK_Profile_Gender_Id FOREIGN KEY (GenderId)
REFERENCES Gender (Id);

--
-- Создать внешний ключ
--
ALTER TABLE Profile
ADD CONSTRAINT FK_Profile_User_Id FOREIGN KEY (UserId)
REFERENCES User (Id) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Создать таблицу `Movie`
--
CREATE TABLE Movie (
  Id int UNSIGNED NOT NULL AUTO_INCREMENT,
  Name tinytext DEFAULT NULL,
  NameInternational tinytext DEFAULT NULL,
  Year int UNSIGNED DEFAULT NULL,
  Created datetime DEFAULT (NOW()),
  Updated datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (Id)
)
ENGINE = INNODB,
CHARACTER SET utf8mb4,
COLLATE utf8mb4_0900_ai_ci;

--
-- Создать таблицу `WillWatch`
--
CREATE TABLE WillWatch (
  UserId int UNSIGNED NOT NULL,
  MovieId int UNSIGNED NOT NULL,
  Created datetime DEFAULT (NOW()),
  PRIMARY KEY (UserId, MovieId)
)
ENGINE = INNODB,
CHARACTER SET utf8mb4,
COLLATE utf8mb4_0900_ai_ci,
COMMENT = 'Буду смотреть';

--
-- Создать внешний ключ
--
ALTER TABLE WillWatch
ADD CONSTRAINT FK_UserMovie_Movie_Id FOREIGN KEY (MovieId)
REFERENCES Movie (Id);

--
-- Создать внешний ключ
--
ALTER TABLE WillWatch
ADD CONSTRAINT FK_UserMovie_User_Id FOREIGN KEY (UserId)
REFERENCES User (Id);

--
-- Создать таблицу `MovieRating`
--
CREATE TABLE MovieRating (
  UserId int UNSIGNED NOT NULL,
  MovieId int UNSIGNED NOT NULL,
  Value tinyint NOT NULL DEFAULT 0,
  Created datetime DEFAULT (NOW()),
  Updated datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (UserId, MovieId)
)
ENGINE = INNODB,
CHARACTER SET utf8mb4,
COLLATE utf8mb4_0900_ai_ci,
COMMENT = 'Оценка пользователя';

--
-- Создать внешний ключ
--
ALTER TABLE MovieRating
ADD CONSTRAINT FK_MovieRating_Movie_Id FOREIGN KEY (MovieId)
REFERENCES Movie (Id);

--
-- Создать внешний ключ
--
ALTER TABLE MovieRating
ADD CONSTRAINT FK_MovieRating_User_Id FOREIGN KEY (UserId)
REFERENCES User (Id);

--
-- Создать таблицу `MovieGenre`
--
CREATE TABLE MovieGenre (
  MovieId int UNSIGNED NOT NULL,
  GenreId int UNSIGNED NOT NULL,
  Created datetime DEFAULT (NOW()),
  PRIMARY KEY (MovieId, GenreId)
)
ENGINE = INNODB,
CHARACTER SET utf8mb4,
COLLATE utf8mb4_0900_ai_ci;

--
-- Создать внешний ключ
--
ALTER TABLE MovieGenre
ADD CONSTRAINT FK_MovieGenre_Genre_Id FOREIGN KEY (GenreId)
REFERENCES Genre (Id);

--
-- Создать внешний ключ
--
ALTER TABLE MovieGenre
ADD CONSTRAINT FK_MovieGenre_Movie_Id FOREIGN KEY (MovieId)
REFERENCES Movie (Id);

--
-- Создать таблицу `MovieCountry`
--
CREATE TABLE MovieCountry (
  MovieId int UNSIGNED NOT NULL,
  CountryId int UNSIGNED NOT NULL,
  Created datetime DEFAULT (NOW()),
  PRIMARY KEY (MovieId, CountryId)
)
ENGINE = INNODB,
CHARACTER SET utf8mb4,
COLLATE utf8mb4_0900_ai_ci;

--
-- Создать внешний ключ
--
ALTER TABLE MovieCountry
ADD CONSTRAINT FK_MovieCountry_Country_Id FOREIGN KEY (CountryId)
REFERENCES Country (Id);

--
-- Создать внешний ключ
--
ALTER TABLE MovieCountry
ADD CONSTRAINT FK_MovieCountry_Movie_Id FOREIGN KEY (MovieId)
REFERENCES Movie (Id);

--
-- Создать таблицу `FavoriteFilms`
--
CREATE TABLE FavoriteFilms (
  UserId int UNSIGNED NOT NULL,
  MovieId int UNSIGNED NOT NULL,
  Created datetime DEFAULT (NOW()),
  PRIMARY KEY (UserId, MovieId)
)
ENGINE = INNODB,
CHARACTER SET utf8mb4,
COLLATE utf8mb4_0900_ai_ci,
COMMENT = 'Любимые фильмы';

--
-- Создать внешний ключ
--
ALTER TABLE FavoriteFilms
ADD CONSTRAINT FK_FavoriteFilms_Movie_Id FOREIGN KEY (MovieId)
REFERENCES Movie (Id);

--
-- Создать внешний ключ
--
ALTER TABLE FavoriteFilms
ADD CONSTRAINT FK_FavoriteFilms_User_Id FOREIGN KEY (UserId)
REFERENCES User (Id);

-- 
-- Вывод данных для таблицы Gender
--
-- Таблица kinopoisk.Gender не содержит данных

-- 
-- Вывод данных для таблицы Genre
--
-- Таблица kinopoisk.Genre не содержит данных

-- 
-- Вывод данных для таблицы Country
--
-- Таблица kinopoisk.Country не содержит данных

-- 
-- Вывод данных для таблицы User
--
-- Таблица kinopoisk.User не содержит данных

-- 
-- Вывод данных для таблицы Movie
--
-- Таблица kinopoisk.Movie не содержит данных

-- 
-- Вывод данных для таблицы WillWatch
--
-- Таблица kinopoisk.WillWatch не содержит данных

-- 
-- Вывод данных для таблицы Profile
--
-- Таблица kinopoisk.Profile не содержит данных

-- 
-- Вывод данных для таблицы MovieRating
--
-- Таблица kinopoisk.MovieRating не содержит данных

-- 
-- Вывод данных для таблицы MovieGenre
--
-- Таблица kinopoisk.MovieGenre не содержит данных

-- 
-- Вывод данных для таблицы MovieCountry
--
-- Таблица kinopoisk.MovieCountry не содержит данных

-- 
-- Вывод данных для таблицы FavoriteFilms
--
-- Таблица kinopoisk.FavoriteFilms не содержит данных

-- 
-- Восстановить предыдущий режим SQL (SQL mode)
--
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;

-- 
-- Включение внешних ключей
-- 
/*!40014 SET FOREIGN_KEY_CHECKS = @OLD_FOREIGN_KEY_CHECKS */;